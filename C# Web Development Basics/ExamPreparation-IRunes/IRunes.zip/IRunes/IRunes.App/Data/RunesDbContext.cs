﻿namespace IRunes.App.Data
{
    using Microsoft.EntityFrameworkCore;

    public class RunesDbContext : DbContext
    {
        // TODO
    }
}
