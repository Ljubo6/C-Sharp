﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1._Initial_Setup
{
    public static class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-OE6JNPK\\SQLEXPRESS;Database=MinionsDB;Trusted_Connection=True";

    }
}
