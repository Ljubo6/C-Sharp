﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiniORM.App
{
    class Configuration
    {
        public const string ConnectionString = "Server=DESKTOP-OE6JNPK\\SQLEXPRESS;Database=MiniORM;Trusted_Connection=True";

    }
}
