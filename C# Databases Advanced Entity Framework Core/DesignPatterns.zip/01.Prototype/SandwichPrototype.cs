﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Prototype
{
    public abstract class SandwichPrototype
    {
        public abstract SandwichPrototype Clone();
    }
}
